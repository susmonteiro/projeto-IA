# -*- coding: utf-8 -*-
"""
Grupo alxxx
Student id #77777
Student id #77777
"""

import numpy as np

def createdecisiontree(D,Y, noise = False):
    
    return [0,0,1]
